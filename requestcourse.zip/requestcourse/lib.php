<?php
defined('MOODLE_INTERNAL') || die;


function local_requestcourse_extend_navigation(global_navigation $navigation) {
    global $CFG, $PAGE, $USER;

   

   if(!is_siteadmin() && !isguestuser() && isloggedin()){
       
       $reqCourse=$navigation->add('Request a Course', new moodle_url($CFG->wwwroot . '/course/request.php'));
   }
   
   if(is_siteadmin() && isloggedin()){
       
       $reqCourse=$navigation->add('Pending Course Request', new moodle_url($CFG->wwwroot . '/course/pending.php'));
   }
 }
