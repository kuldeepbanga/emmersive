<?php

defined('MOODLE_INTERNAL') || die();

$plugin->version        = 2016102400;                   
$plugin->requires       = 2016051900;                  
$plugin->component      = 'local_requestcourse';