<?php
namespace local_quiz_reattempt;

defined('MOODLE_INTERNAL') || die();

require_once(dirname(__DIR__).'/lib.php');

class observers
{
    public static function user_quiz_reattempt(\mod_quiz\event\course_module_viewed $event) {
        if ( empty($event->objectid)) {
		
		
            return;
        }
		check_quiz_reattempt($event);	
    }
	
	public static function unenrol_enrol_user(\core\event\user_loggedin $event2) {
	
	
        if ( empty($event2->objectid)) {
            return;
        }reenrol_course($event2);	
    }
}