<?php

$string['pluginname'] = 'Quiz Reattempt';
$string['calculated'] = 'Calculated';
$string['calculatedquestion'] = 'Calculated question not supported at line {$a}. The question will be ignored';
$string['cannotcreatepath'] = 'Path cannot be created ({$a})';
$string['cannoteditafterattempts'] = 'You cannot add or remove questions because this quiz has been attempted. ({$a})';
$string['cannotfindprevattempt'] = 'Cannot find previous attempt to build on.';
$string['cannotfindquestionregard'] = 'Failed to get questions for regrading!';
$string['cannotinsert'] = 'Cannot insert question';
$string['cannotinsertrandomquestion'] = 'Could not insert new random question!';
$string['cannotloadquestion'] = 'Could not load question options';
$string['cannotloadtypeinfo'] = 'Unable to load questiontype specific question information';
$string['cannotopen'] = 'Cannot open export file ({$a})';
$string['cannotrestore'] = 'Could not restore question sessions';
$string['cannotreviewopen'] = 'You cannot review this attempt, it is still open.';
$string['cannotsavelayout'] = 'Could not save layout';
$string['cannotsavenumberofquestion'] = 'Could not save number of questions per page';
$string['cannotsavequestion'] = 'Cannot save question list';
$string['cannotsetgrade'] = 'Could not set a new maximum grade for the quiz';
$string['cannotsetsumgrades'] = 'Failed to set sumgrades';
$string['cannotstartgradesmismatch'] = 'Cannot start an attempt at this quiz. The quiz is set to be graded out of {$a->grade}, but none of the questions in the quiz have a grade. This can be fixed on the \'Edit quiz\' page.';
$string['cannotstartmissingquestion'] = 'Cannot start an attempt at this quiz. The quiz definition includes a question that does not exist.';
$string['cannotstartnoquestions'] = 'Cannot start an attempt at this quiz. The quiz has not been set up yet. No questions have been added.';
$string['cannotwrite'] = 'Cannot write to export file ({$a})';
$string['canredoquestions'] = 'Allow redo within an attempt';
$string['canredoquestions_desc'] = 'If enabled, then when students have finished attempting particular question, they will see a Redo question button. This allows them to attempt another version of the same question, without having to submit the entire quiz attempt and start another one. This option is mainly useful for practice quizzes.

This setting only affects questions (for example not Essay questions) and behaviours (for example Immediate feedback, or Interactive with multiple tries) where it is possible for student to finish the question before the attempt is submitted.';
$string['canredoquestions_help'] = 'If enabled, then when students have finished attempting particular question, they will see a Redo question button. This allows them to attempt another version of the same question, without having to submit the entire quiz attempt and start another one. This option is mainly useful for practice quizzes.

This setting only affects questions (for example not Essay questions) and behaviours (for example Immediate feedback, or Interactive with multiple tries) where it is possible for student to finish the question before the attempt is submitted.';
$string['canredoquestionsyes'] = 'Students may redo another version of any finished question';
$string['caseno'] = 'No, case is unimportant';
$string['casesensitive'] = 'Case sensitivity';
$string['caseyes'] = 'Yes, case must match';
$string['categoryadded'] = 'The category \'{$a}\' was added';
$string['categorydeleted'] = 'The category \'{$a}\' was deleted';
$string['categorynoedit'] = 'You do not have editing privileges in the category \'{$a}\'.';
$string['categoryupdated'] = 'The category was successfully updated';
$string['close'] = 'Close window';
$string['closed'] = 'Closed';
$string['closebeforeopen'] = 'Could not update the quiz. You have specified a close date before the open date.';
$string['closepreview'] = 'Close preview';
$string['closereview'] = 'Close review';
$string['comment'] = 'Comment';
$string['commentorgrade'] = 'Make comment or override grade';
$string['comments'] = 'Comments';
$string['completedon'] = 'Completed on';
$string['completionpass'] = 'Require passing grade';
$string['completionpass_help'] = 'If enabled, this activity is considered complete when the student receives a passing grade, with the pass grade set in the gradebook.';
$string['completionattemptsexhausted'] = 'Or all available attempts completed';
$string['completionattemptsexhausted_help'] = 'Mark quiz complete when the student has exhausted the maximum number of attempts.';
$string['configadaptive'] = 'If you choose Yes for this option then the student will be allowed multiple responses to a question even within the same attempt at the quiz.';
$string['configattemptsallowed'] = 'Restriction on the number of attempts students are allowed at the quiz.';
$string['configdecimaldigits'] = 'Number of digits that should be shown after the decimal point when displaying grades.';
$string['configdecimalplaces'] = 'Number of digits that should be shown after the decimal point when displaying grades for the quiz.';
$string['configdecimalplacesquestion'] = 'Number of digits that should be shown after the decimal point when displaying the grade for individual questions.';
$string['configdelaylater'] = 'If you set a time delay here, the student cannot start their third, fourth, ... attempt until this much time has passed since the end of their previous attempt.';
$string['configdelay1'] = 'If you set a time delay, then a student has to wait for that time before they can attempt a quiz after the first attempt.';
$string['configdelay1st2nd'] = 'If you set a time delay here, the student cannot start their second attempt until this much time has passed since the end of their first attempt.';
$string['configdelay2'] = 'If you set a time delay here, then a student has to wait for that time before they can attempt their third or later attempts.';
$string['configeachattemptbuildsonthelast'] = 'If multiple attempts are allowed then each new attempt contains the results of the previous attempt.';
$string['configgrademethod'] = 'When multiple attempts are allowed, which method should be used to calculate the student\'s final grade for the quiz.';
$string['configintro'] = 'The values you set here define the default values that are used in the settings form when you create a new quiz. You can also configure which quiz settings are considered advanced.';
$string['configmaximumgrade'] = 'The default grade that the quiz grade is scaled to be out of.';
$string['confignewpageevery'] = 'When adding questions to the quiz page breaks will automatically be inserted according to the setting you choose here.';
$string['confignavmethod'] = 'In Free navigation, questions may be answered in any order using navigation. In Sequential, questions must be answered in strict sequence.';
$string['configoutcomesadvanced'] = 'If this option is turned on, then the Outcomes on the quiz editing form are advanced settings.';
$string['configpenaltyscheme'] = 'Penalty subtracted for each wrong response in adaptive mode.';
$string['configpopup'] = 'Force the attempt to open in a popup window, and use JavaScript tricks to try to restrict copy and paste, etc. during quiz attempts.';
$string['configrequirepassword'] = 'Students must enter this password before they can attempt the quiz.';
$string['configrequiresubnet'] = 'Students can only attempt the quiz from these computers.';
$string['configreviewoptions'] = 'These options control what information users can see when they review a quiz attempt or look at the quiz reports.';
$string['configshowblocks'] = 'Show blocks during quiz attempts.';
$string['configshowuserpicture'] = 'Show the user\'s picture on screen during attempts.';
$string['configshufflewithin'] = 'If you enable this option, then the parts making up the individual questions will be randomly shuffled each time a student starts an attempt at this quiz, provided the option is also enabled in the question settings.';
$string['configtimelimit'] = 'Default time limit for quizzes in minutes. 0 mean no time limit.';
$string['configtimelimitsec'] = 'Default time limit for quizzes in seconds. 0 mean no time limit.';
$string['configurerandomquestion'] = 'Configure question';
$string['confirmclose'] = 'Once you submit, you will no longer be able to change your answers for this attempt.';
$string['confirmremovequestion'] = 'Are you sure you want to remove this {$a} question?';
$string['confirmremovesectionheading'] = 'Are you sure you want to remove the \'{$a}\' section heading?';
$string['confirmserverdelete'] = 'Are you sure you want to remove the server <b>{$a}</b> from the list?';
$string['confirmstartattemptlimit'] = 'Number of attempts allowed:  {$a}. You are about to start a new attempt.  Do you wish to proceed?';
$string['confirmstartattempttimelimit'] = 'This quiz has a time limit and is limited to {$a} attempt(s). You are about to start a new attempt.  Do you wish to proceed?';
$string['confirmstarttimelimit'] = 'The quiz has a time limit. Are you sure that you wish to start?';
$string['connectionok'] = 'Network connection restored. You may continue safely.';
$string['connectionerror'] = 'Network connection lost. (Autosave failed).

Make a note of any responses entered on this page in the last few minutes, then try to re-connect.

Once connection has been re-established, your responses should be saved and this message will disappear.';
$string['containercategorycreated'] = 'This category has been created to store all the original categories moved to site level due to the causes specified below.';
$string['continueattemptquiz'] = 'Continue the last attempt';
$string['continuepreview'] = 'Continue the last preview';
$string['copyingfrom'] = 'Creating a copy of the question \'{$a}\'';
$string['copyingquestion'] = 'Copying a question';
$string['correct'] = 'Correct';
$string['correctanswer'] = 'Correct answer';
$string['correctanswerformula'] = 'Correct answer formula';
$string['correctansweris'] = 'Correct answer: {$a}';
$string['correctanswerlength'] = 'Significant figures';
$string['correctanswers'] = 'Correct answers';
$string['correctanswershows'] = 'Correct answer shows';
$string['corrresp'] = 'Correct response';
$string['countdown'] = 'Countdown';
$string['countdownfinished'] = 'The quiz is closing, you should submit your answers now.';
$string['countdowntenminutes'] = 'The quiz will be closing in ten minutes.';
$string['coursetestmanager'] = 'Course Test Manager format';
$string['createcategoryandaddrandomquestion'] = 'Create category and add random question';
$string['createfirst'] = 'You must create some short-answer questions first.';
$string['createmultiple'] = 'Add several random questions to quiz';
$string['createnewquestion'] = 'Create new question';
$string['createquestionandadd'] = 'Create a new question and add it to the quiz.';
$string['custom'] = 'Custom format';
$string['dataitemneed'] = 'You need to add at least one set of data items to get a valid question';
$string['datasetdefinitions'] = 'Reusable dataset definitions for category {$a}';
$string['datasetnumber'] = 'Number';
$string['daysavailable'] = 'Days available';
$string['decimaldigits'] = 'Decimal digits in grades';
$string['decimalplaces'] = 'Decimal places in grades';
$string['decimalplaces_help'] = 'This setting specifies the number of digits shown after the decimal point when displaying grades. It only affects the display of grades, not the grades stored in the database, nor the internal calculations, which are carried out to full accuracy.';
$string['decimalplacesquestion'] = 'Decimal places in question grades';
$string['decimalplacesquestion_help'] = 'This setting specifies the number of digits shown after the decimal point when displaying the grades for individual questions.';
$string['decimalpoints'] = 'Decimal points';
$string['default'] = 'Default';
$string['defaultgrade'] = 'Default question grade';
$string['defaultinfo'] = 'The default category for questions.';
$string['delaylater'] = 'Enforced delay between later attempts';
$string['delaylater_help'] = 'If enabled, a student must wait for the specified time to elapse before attempting the quiz a third time and any subsequent times.';
$string['delay1'] = 'Time delay between first and second attempt';
$string['delay1st2nd'] = 'Enforced delay between 1st and 2nd attempts';
$string['delay1st2nd_help'] = 'If enabled, a student must wait for the specified time to elapse before being able to attempt the quiz a second time.';
$string['delay2'] = 'Time delay between later attempts';
$string['deleteattemptcheck'] = 'Are you absolutely sure you want to completely delete these attempts?';
$string['deleteselected'] = 'Delete selected';
$string['deletingquestionattempts'] = 'Deleting question attempts';
$string['description'] = 'Description';
$string['disabled'] = 'Disabled';
$string['displayoptions'] = 'Display options';
$string['donotuseautosave'] = 'Do not use auto-save';
$string['download'] = 'Click to download the exported category file';
$string['downloadextra'] = '(file is also stored in the course files in the /backupdata/quiz folder)';
$string['dragtoafter'] = 'After {$a}';
$string['dragtostart'] = 'To the start';
$string['duplicateresponse'] = 'This submission has been ignored because you gave an equivalent answer earlier.';
$string['eachattemptbuildsonthelast'] = 'Each attempt builds on the last';
$string['eachattemptbuildsonthelast_help'] = 'If multiple attempts are allowed and this setting is enabled, each new quiz attempt will contain the results of the previous attempt. This allows a quiz to be completed over several attempts.';
$string['editcategories'] = 'Edit categories';
$string['editcategory'] = 'Edit category';
$string['editcatquestions'] = 'Edit category questions';
$string['editingquestion'] = 'Editing a question';
$string['editingquiz'] = 'Editing quiz';
$string['editingquiz_help'] = 'When creating a quiz, the main concepts are:

* The quiz, containing questions over one or more pages
* The question bank, which stores copies of all questions organised into categories
* Random questions -  A student gets different questions each time they attempt the quiz and different students can get different questions';
$string['editingquiz_link'] = 'mod/quiz/edit';
$string['editingquizx'] = 'Editing quiz: {$a}';
$string['editmaxmark'] = 'Edit maximum mark';
$string['editoverride'] = 'Edit override';
$string['editqcats'] = 'Edit questions categories';
$string['editquestion'] = 'Edit question';
$string['editquestions'] = 'Edit questions';
$string['editquiz'] = 'Edit quiz';
$string['editquizquestions'] = 'Edit quiz questions';
$string['emailconfirmbody'] = 'Dear {$a->username},

Thank you for submitting your answers to
\'{$a->quizname}\'
in course \'{$a->coursename}\'
at {$a->submissiontime}.

This message confirms that we have safely received your answers.

You can access this quiz at {$a->quizurl}.';
$string['emailconfirmsmall'] = 'Thank you for submitting your answers to \'{$a->quizname}\'';
$string['emailconfirmsubject'] = 'Submission confirmation: {$a->quizname}';
$string['emailnotifybody'] = 'Dear {$a->username},

{$a->studentname} has completed
\'{$a->quizname}\' ({$a->quizurl})
in course \'{$a->coursename}\'

You can review this attempt at {$a->quizreviewurl}.';
$string['emailnotifysmall'] = '{$a->studentname} has completed {$a->quizname}. See {$a->quizreviewurl}';
$string['emailnotifysubject'] = '{$a->studentname} has completed {$a->quizname}';
$string['emailoverduebody'] = 'Dear {$a->studentname},

You started an attempt at \'{$a->quizname}\'
in course \'{$a->coursename}\', but you never submitted it. It should have been
submitted by {$a->attemptduedate}.

If you would still like to submit this attempt, please go to
{$a->attemptsummaryurl} and click the submit button.
You must do this before {$a->attemptgraceend}
otherwise your attempt will not be counted.';
$string['emailoverduesmall'] = 'You did not submit your attempt at {$a->quizname}. Please go to {$a->attemptsummaryurl} before {$a->attemptgraceend} if you would still like to submit.';
$string['emailoverduesubject'] = 'Attempt now overdue: {$a->quizname}';
$string['empty'] = 'Empty';
$string['enabled'] = 'Enabled';
$string['endtest'] = 'Finish attempt ...';
$string['erroraccessingreport'] = 'You cannot access this report';
$string['errorinquestion'] = 'Error in question';
$string['errormissingquestion'] = 'Error: The system is missing the question with id {$a}';
$string['errornotnumbers'] = 'Error - answers must be numeric';
$string['errorunexpectedevent'] = 'Unexpected event code {$a->event} found for question {$a->questionid} in attempt {$a->attemptid}.';
$string['essay'] = 'Essay';
$string['essayquestions'] = 'Questions';
$string['eventattemptdeleted'] = 'Quiz attempt deleted';
$string['eventattemptpreviewstarted'] = 'Quiz attempt preview started';
$string['eventattemptreviewed'] = 'Quiz attempt reviewed';
$string['eventattemptsummaryviewed'] = 'Quiz attempt summary viewed';
$string['eventattemptviewed'] = 'Quiz attempt viewed';
$string['eventeditpageviewed'] = 'Quiz edit page viewed';
$string['eventoverridecreated'] = 'Quiz override created';
$string['eventoverridedeleted'] = 'Quiz override deleted';
$string['eventoverrideupdated'] = 'Quiz override updated';
$string['eventquestionmanuallygraded'] = 'Question manually graded';
$string['eventquizattemptabandoned'] = 'Quiz attempt abandoned';
$string['eventquizattempttimelimitexceeded'] = 'Quiz attempt time limit exceeded';
$string['eventquizattemptstarted'] = 'Quiz attempt started';
$string['eventquizattemptsubmitted'] = 'Quiz attempt submitted';
$string['eventreportviewed'] = 'Quiz report viewed';
$string['everynquestions'] = 'Every {$a} questions';
$string['everyquestion'] = 'Every question';
$string['everythingon'] = 'Everything on';
$string['exportcategory'] = 'export category';
$string['exporterror'] = 'An error occurred during export processing';
$string['exportingquestions'] = 'Questions are being exported to file';
$string['exportname'] = 'File name';
$string['exportquestions'] = 'Export questions to file';
$string['extraattemptrestrictions'] = 'Extra restrictions on attempts';
$string['false'] = 'False';
$string['feedback'] = 'Feedback';
$string['feedbackerrorboundaryformat'] = 'Feedback grade boundaries must be either a percentage or a number. The value you entered in boundary {$a} is not recognised.';
$string['feedbackerrorboundaryoutofrange'] = 'Feedback grade boundaries must be between 0% and 100%. The value you entered in boundary {$a} is out of range.';
$string['feedbackerrorjunkinboundary'] = 'You must fill in the feedback grade boundary boxes without leaving any gaps.';
$string['feedbackerrorjunkinfeedback'] = 'You must fill in the feedback boxes without leaving any gaps.';
$string['feedbackerrororder'] = 'Feedback grade boundaries must be in order, highest first. The value you entered in boundary {$a} is out of sequence.';
$string['file'] = 'File';
$string['fileformat'] = 'File format';
$string['fillcorrect'] = 'Fill with correct';
$string['filloutnumericalanswer'] = 'You provide at least one possible answer and tolerance. The first matching answer will be used to determine the grade and feedback. If you supply some feedback with no answer at the end, that will be shown to students whose response is not matched by any of the other answers.';
$string['filloutoneanswer'] = 'You must provide at least one possible answer. Answers left blank will not be used. \'*\' can be used as a wildcard to match any characters. The first matching answer will be used to determine the grade and feedback.';
$string['filloutthreequestions'] = 'You must provide at least three questions with matching answers. You can provide extra wrong answers by giving an answer with a blank question. Entries where both the question and the answer are blank will be ignored.';
$string['fillouttwochoices'] = 'You must fill out at least two choices.  Choices left blank will not be used.';
$string['finishattemptdots'] = 'Finish attempt...';
$string['finishreview'] = 'Finish review';
$string['forceregeneration'] = 'force regeneration';
$string['formatnotfound'] = 'Import/export format {$a} not found';
$string['formulaerror'] = 'Formula errors!';
$string['fractionsaddwrong'] = 'The positive grades you have chosen do not add up to 100%<br />Instead, they add up to {$a}%<br />Do you want to go back and fix this question?';
$string['fractionsnomax'] = 'One of the answers should be 100%, so that it is<br />possible to get a full grade for this question.<br />Do you want to go back and fix this question?';
$string['fromfile'] = 'from file:';
$string['functiondisabledbysecuremode'] = 'That functionality is currently disabled';
$string['generalfeedback'] = 'General feedback';
$string['generalfeedback_help'] = 'General feedback is text which is shown after a question has been attempted. Unlike feedback for a specific question which depends on the response given, the same general feedback is always shown.';
$string['graceperiod'] = 'Submission grace period';
$string['graceperiod_desc'] = 'If what to do when time expires is set to \'Allow a grace period to submit, but not change any responses\', this is the default amount of extra time that is allowed.';
$string['graceperiod_help'] = 'If what to do when time expires is set to \'Allow a grace period to submit, but not change any responses\', this is the amount of extra time that is allowed.';
$string['graceperiodmin'] = 'Last submission grace period';
$string['graceperiodmin_desc'] = 'There is a potential problem right at the end of the quiz. On the one hand, we want to let students continue working right up until the last second - with the help of the timer that automatically submits the quiz when time runs out. On the other hand, the server may then be overloaded, and take some time to get to process the responses. Therefore, we will accept responses for up to this long after time expires, so they are not penalised for the server being slow. However, the student could cheat and get this many seconds to answer the quiz. You have to make a trade-off based on how much you trust the performance of your server during quizzes.';
$string['graceperiodtoosmall'] = 'The grace period must be more than {$a}.';
$string['grade'] = 'Grade';
$string['gradeall'] = 'Grade all';
$string['gradeaverage'] = 'Average grade';
$string['gradeboundary'] = 'Grade boundary';
$string['gradeessays'] = 'Grade essays';
$string['gradehighest'] = 'Highest grade';
$string['grademethod'] = 'Grading method';