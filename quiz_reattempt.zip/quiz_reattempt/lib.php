<?php

    function check_quiz_reattempt($event)
    {  
       global $DB,$USER,$CFG, $COURSE;
                
       $courseid = $COURSE->id;
       $id = optional_param('id', null, PARAM_INT);
       if($id)
	   {
		    $result_cm = $DB->get_record('course_modules', array('id'=>$id), $fields='*', $strictness=IGNORE_MISSING) ; 
			$courseid = $result_cm->course;
			$moduleid=$result_cm->module;
			$instanceid=$result_cm->instance;
			   
			$result_attempt = $DB->get_record('quiz',  array('id'=>$result_cm->instance), $fields='*', $strictness=IGNORE_MISSING) ;
			$attempt=$result_attempt->attempts; 
			   
			$result_user_attempt = $DB->get_record('quiz_attempts',  array('quiz'=>$instanceid,'userid'=>$USER->id,'attempt'=>1), $fields='*', $strictness=IGNORE_MISSING) ;
			   
			$result_reattempt = $DB->get_record('quiz_reattempt',   array('instanceid'=>$instanceid,'courseid'=>$courseid,'moduleid'=>$moduleid,'userid'=>$USER->id), $fields='*', $strictness=IGNORE_MISSING);
	   
	   }else{
		  
		    echo "error...";
	   }
     
       
       
       if($result_user_attempt!=null && $result_reattempt==null)
       {
       
    
            if($result_user_attempt->state=='finished' && $moduleid==16 && $attempt==1  )
            { 
                if(($result_user_attempt->sumgrades>=7) && ($result_user_attempt->sumgrades<8))
                {
                   
                   $record = new stdClass();
                   $record->courseid       = $courseid;
                   $record->userid         = $USER->id;
                   $record->moduleid       = $moduleid;
                   $record->instanceid     = $instanceid;
                   $lastinsertid = $DB->insert_record('quiz_reattempt', $record, true, false);

                   if($lastinsertid)
                   { 
                      $DB->delete_records('quiz_attempts', array('quiz'=>$instanceid,'userid'=>$USER->id,'attempt'=>1));
                      $DB->delete_records('quiz_grades',  array('quiz'=>$instanceid,'userid'=>$USER->id)) ;
                   }
                }

            }  
          
        }
     
    }
	
	function reenrol_course()
	{

	    global $DB,$USER,$CFG, $COURSE;
	
	    $userid= $USER->id;
	    $enrols = enrol_get_plugins(true);

	    $student_enrol_courses = enrol_get_users_courses($USER->id);
	 
	    foreach($student_enrol_courses as $student_enrol_course)
		{
	            
				$result_cms = $DB->get_records('course_modules', array('course'=>$student_enrol_course->id, 'module'=>16),null,'id,course,instance,module') ;
				  
				foreach($result_cms as $result_cm)
				{
				  
				        $result_user_attempt = $DB->get_record('quiz_attempts',  array('quiz'=>$result_cm->instance,'userid'=>$USER->id,'attempt'=>1), $fields='*', $strictness=IGNORE_MISSING) ;
						
						$result_reattempt = $DB->get_record('quiz_reattempt',   array('instanceid'=>$result_cm->instance,'courseid'=>$student_enrol_course->id,'moduleid'=>16,'userid'=>$USER->id),$fields='*', $strictness=IGNORE_MISSING);
						 
						if($result_user_attempt!=null)
						{
						   if(($result_user_attempt->sumgrades < 7 && $result_user_attempt->state=='finished' && $result_reattempt==null) || ($result_user_attempt->sumgrades < 8 && $result_user_attempt->state=='finished' && $result_reattempt!=null) )
						   { 
								$DB->delete_records('quiz_reattempt', array('instanceid'=>$result_cm->instance,'courseid'=>$student_enrol_course->id,'userid'=>$USER->id));
								
												
								$DB->delete_records('quiz_attempts', array('quiz'=>$result_cm->instance,'userid'=>$USER->id,'attempt'=>1));
								$DB->delete_records('quiz_grades',  array('quiz'=>$result_cm->instance,'userid'=>$USER->id)) ;
								
								//Unenroll User from the course							
								
								$instances = $DB->get_records('enrol', array('courseid' => $student_enrol_course->id));
									foreach ($instances as $instance)
									{
										$plugin = enrol_get_plugin($instance->enrol);
										$plugin->unenrol_user($instance, $USER->id);
									}
													
								// Enrol User to the course
								
								$enrolData = $DB->get_record('enrol', array('enrol'=>'manual', 'courseid'=>$student_enrol_course->id));          
								$user_enrolment = new stdClass();                                                              
								$user_enrolment->enrolid = $enrolData->id;                                                 
								$user_enrolment->status = '0';                                                             
								$user_enrolment->userid = $USER->id;                                                         
								$user_enrolment->timestart = time();                                                       
								$user_enrolment->timeend =  '0';                                                           
								$user_enrolment->modifierid = 2;                                                   
								//Modifierid in this table is userid who enrolled this user manually
								$user_enrolment->timecreated = time();                                                     
								$user_enrolment->timemodified = time();                                                    
								$insertId = $DB->insert_record('user_enrolments', $user_enrolment);                            
								//addto log                                                                                    
								$context = $DB->get_record('context', array('contextlevel'=>50, 'instanceid'=>$student_enrol_course->id));          
								$role = new stdClass();                                                                        
								$role->roleid = 5;                                                                         
								$role->contextid = $context->id;                                                           
								$role->userid = $USER->id;                                                                   
								$role->component = '';                                                                     
								$role->itemid = 0;                                                                         
								$role->timemodified = time();                                                              
								$role->modifierid = 2;                                                             
							    $insertId2 = $DB->insert_record('role_assignments', $role);                                    
								add_to_log($student_enrol_course->id, '', 2, 'automated');                
								//return array('user_enrolment'=>$insertId, 'role_assignment'=>$insertId2);  
								
							
                           }
						} 
						   
						  
                }
				 
	    }
						
	}

?>
